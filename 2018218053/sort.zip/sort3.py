#Sorting.py

Str = input("请输入一个仅含有0-9的字符串：")
ListA = list(Str)
#print(ListA)
ListB = set(ListA)
L =[0,0,0,0,0,0,0,0,0,0]
for item in ListB:
    L[int(item)] = ListA.count(item)

    
for i in range(10):
    while L[i] > 0:
        print(i,end="")
        L[i] = L[i] - 1
