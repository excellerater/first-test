#Sorting.py
Str = input("请输入一个仅含有0-9的字符串：")
d = {}
for c in Str:
    if not c in d:
        d[c] = 1
    else:
        d[c] = d[c] + 1
#print(d)

List = []
for key in d:
    while d[key] > 0:
        List.append(int(key))
        d[key] = d[key]-1
#print(List)

for i in range(1,len(List)):
    for j in range(i,0,-1):
        if List[j]<List[j-1]:
            List[j],List[j-1]=List[j-1],List[j]
        else:
            break

for item in List:
    print(item,end="")
