#Sorting.py

def Sta(Str,L):
    for c in Str:
       L[int(c)] = L[int(c)] + 1
    for j in range(10):
        while L[j] > 0:
            print(j,end="")
            L[j] = L[j]-1

def main():
    Str = input("请输入一个仅含有0-9的字符串：")
    L = [0,0,0,0,0,0,0,0,0,0]
    Sta(Str,L)
main()


    
