#Sorting.py
Str = input("请输入一个仅含有0-9的字符串：")
ListA = list(Str)
List = []
for i in ListA:
    List.append(int(i))

for i in range(1,len(List)):
    for j in range(i,0,-1):
        if List[j]<List[j-1]:
            List[j],List[j-1]=List[j-1],List[j]
        else:
            break

for item in List:
    print(item,end="")
